import './App.css';
import React from 'react';

function App() {
  return (
    <div className="App">
      <>
      <h1>Hello Dojo!</h1>
      </>
      <h2>Things I need to do:</h2>
        <ul className = "list">
          <li>* Learn React</li>
          <li>* Climb Mt. Everest</li>
          <li>* Run a Marathon</li>
          <li>* Feed the dogs</li>
        </ul>
    </div>
  );
}

export default App;
